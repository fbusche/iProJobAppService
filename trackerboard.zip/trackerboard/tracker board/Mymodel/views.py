from django.shortcuts import render
from Mymodel.models import trackerboard


def trackerboard(request):
    List = trackerboard.objects.get(id=1)
    Data = {
        "company": List.company,
        "status": List.status,
        "applydate": List.applydate,
    }
    return render(request, 'trackerboard.html', Data)

