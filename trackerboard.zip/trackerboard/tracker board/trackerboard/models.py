from django.db import models

# Create your models here.

class trackerboard(models.Model):
    company = models.CharField(max_length=20)
    status = models.CharField(max_length=30)
    applydate = models.CharField(max_length=30)

